README
INKYOTTER DESIGN FONT RELEASES EULA

============
Personal Use
============

This font is licensed under the Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-nd/3.0/.

===========
Commercial Use
===========

For commercial uses a separate EULA applies, please email niniprower@gmail.com to discuss licensing arrangements.